package userPet;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.tomcat.dbcp.dbcp2.PStmtKey;

public class goodsDAO {
	Connection conn;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	public void connect_cp() {
		try {
			Context initctx = new InitialContext();
			Context envctx = (Context)initctx.lookup("java://comp/env");
			DataSource ds = (DataSource)envctx.lookup("jdbc/pool");
			conn = ds.getConnection();
			System.out.println("Ŀ�ؼ�Ǯ�� ���� ����");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void disconnect() {
		if(conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if(pstmt != null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if(rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		System.out.println("��Ŀ�ؼ� ����");
	}
	
	public void insertGod(goodsBean gdo) {
		connect_cp();
		
		String sql = "insert into goods values (null,?,?,?,?,?,?)";
		
		try {
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, gdo.getName());
			pstmt.setString(2, gdo.getKind());
			pstmt.setString(3, gdo.getPrice());
			pstmt.setString(4, gdo.getCnt());
			pstmt.setInt(5, gdo.getStar());
			pstmt.setString(6, gdo.getDate());
			
			pstmt.executeUpdate();
			System.out.println("insert ó��");			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public ArrayList<goodsBean> getAllGod() {
		connect_cp();
		ArrayList<goodsBean> gList = new ArrayList<goodsBean>();
		String sql = "select * from goods";
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				goodsBean gdo = new goodsBean();
				gdo.setNum(rs.getInt(1));
				gdo.setName(rs.getString(2));
				gdo.setKind(rs.getString(3));
				gdo.setPrice(rs.getString(4));
				gdo.setCnt(rs.getString(5));
				gdo.setStar(rs.getInt(6));
				gdo.setDate(rs.getString(7));
				gList.add(gdo);
			}
			System.out.println("getAllGod ó��");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		disconnect();
		return gList;
		
	}
	
	public goodsBean getGodOne(int num) {
		connect_cp();
		goodsBean gdo = new goodsBean();
		String sql = "select * from goods where num=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				gdo.setNum(rs.getInt(1));
				gdo.setName(rs.getString(2));
				gdo.setKind(rs.getString(3));
				gdo.setPrice(rs.getString(4));
				gdo.setCnt(rs.getString(5));
				gdo.setStar(rs.getInt(6));
				gdo.setDate(rs.getString(7));
			}
			System.out.println("getGodOne ó��");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		disconnect();
		return gdo;
	}
	
	public void goodsM(goodsBean gdo) {
		connect_cp();
		
		String sql = "update goods set name=?, kind=?, price=?, cnt=?, star=?, date=? where num=?";
		try {
			pstmt=conn.prepareStatement(sql);
			
			pstmt.setString(1, gdo.getName());
			pstmt.setString(2, gdo.getKind());
			pstmt.setString(3, gdo.getPrice());
			pstmt.setString(4, gdo.getCnt());
			pstmt.setInt(5, gdo.getStar());
			pstmt.setString(6, gdo.getDate());
			pstmt.setInt(7, gdo.getNum());
			
			pstmt.executeUpdate();
			
			System.out.println("goodsM ó��");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		disconnect();
	}
	
	public void deleteGod(int num) {
		connect_cp();
		
		String sql = "delete from goods where num=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.executeUpdate();
			
			System.out.println("deleteGod ó��");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		disconnect();
	}
	
	
	//Search
	public ArrayList<goodsBean> searchGod(String k, String v) {
		connect_cp();
		ArrayList<goodsBean> gList = new ArrayList<goodsBean>();
		
		if(k.equals("name")) {
			String sql = "select * from goods where name like ?";
			try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, "%" + v + "%");
				rs = pstmt.executeQuery();
				
				while(rs.next()) {
					goodsBean gdo = new goodsBean();
					gdo.setNum(rs.getInt(1));
					gdo.setName(rs.getString(2));
					gdo.setKind(rs.getString(3));
					gdo.setPrice(rs.getString(4));
					gdo.setCnt(rs.getString(5));
					gdo.setStar(rs.getInt(6));
					gdo.setDate(rs.getString(7));
					gList.add(gdo);
					
					System.out.println("ggg");
				}
			} catch(SQLException e) {
				e.printStackTrace();
			}
		} 
		else if(k.equals("kind")) {
			String sql = "select * from goods where kind like ?";
			try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, "%" + v + "%");
				rs = pstmt.executeQuery();
				
				while(rs.next()) {
					goodsBean gdo = new goodsBean();
					gdo.setNum(rs.getInt(1));
					gdo.setName(rs.getString(2));
					gdo.setKind(rs.getString(3));
					gdo.setPrice(rs.getString(4));
					gdo.setCnt(rs.getString(5));
					gdo.setStar(rs.getInt(6));
					gdo.setDate(rs.getString(7));
					gList.add(gdo);
				}
					System.out.println("sss");
			} catch(SQLException e) {
				e.printStackTrace();
			}
			
		}
		disconnect();
		return gList;
	}
	
	
	//sort
	public ArrayList<goodsBean> sortGod(String st, String sort){
		connect_cp();
		ArrayList<goodsBean> gList = new ArrayList<goodsBean>();
		if (sort.equals("asc")) {
			if (st.equals("1")) {
				String sql = "select * from goods order by name asc";
				try {
					pstmt = conn.prepareStatement(sql);
					rs = pstmt.executeQuery();
					while (rs.next()) {
						goodsBean gdo = new goodsBean();
						gdo.setNum(rs.getInt(1));
						gdo.setName(rs.getString(2));
						gdo.setKind(rs.getString(3));
						gdo.setPrice(rs.getString(4));
						gdo.setCnt(rs.getString(5));
						gdo.setStar(rs.getInt(6));
						gdo.setDate(rs.getString(7));
						gList.add(gdo);
					}
					System.out.println("SortHos() ó�� ����");
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
				disconnect();
			}
			
			else if (st.equals("2")) {
				String sql = "select * from goods order by kind asc";
				try {
					pstmt = conn.prepareStatement(sql);
					rs = pstmt.executeQuery();
					while (rs.next()) {
						goodsBean gdo = new goodsBean();
						gdo.setNum(rs.getInt(1));
						gdo.setName(rs.getString(2));
						gdo.setKind(rs.getString(3));
						gdo.setPrice(rs.getString(4));
						gdo.setCnt(rs.getString(5));
						gdo.setStar(rs.getInt(6));
						gdo.setDate(rs.getString(7));
						gList.add(gdo);
					}
					System.out.println("SortHos() ó�� ����");
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
				disconnect();
			}
			
			else if (st.equals("3")) {
				String sql = "select * from goods order by star asc";
				try {
					pstmt = conn.prepareStatement(sql);
					rs = pstmt.executeQuery();
					while (rs.next()) {
						goodsBean gdo = new goodsBean();
						gdo.setNum(rs.getInt(1));
						gdo.setName(rs.getString(2));
						gdo.setKind(rs.getString(3));
						gdo.setPrice(rs.getString(4));
						gdo.setCnt(rs.getString(5));
						gdo.setStar(rs.getInt(6));
						gdo.setDate(rs.getString(7));
						gList.add(gdo);
					}
					System.out.println("SortHos() ó�� ����");
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
				disconnect();
			}
			
			else if (st.equals("4")) {
				String sql = "select * from goods order by date asc";
				try {
					pstmt = conn.prepareStatement(sql);
					rs = pstmt.executeQuery();
					while (rs.next()) {
						goodsBean gdo = new goodsBean();
						gdo.setNum(rs.getInt(1));
						gdo.setName(rs.getString(2));
						gdo.setKind(rs.getString(3));
						gdo.setPrice(rs.getString(4));
						gdo.setCnt(rs.getString(5));
						gdo.setStar(rs.getInt(6));
						gdo.setDate(rs.getString(7));
						gList.add(gdo);
					}
					System.out.println("SortHos() ó�� ����");
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
				disconnect();
			}
		} else if (sort.equals("desc")) {
			if (st.equals("1")) {
				String sql = "select * from goods order by name desc";
				try {
					pstmt = conn.prepareStatement(sql);
					rs = pstmt.executeQuery();
					while (rs.next()) {
						goodsBean gdo = new goodsBean();
						gdo.setNum(rs.getInt(1));
						gdo.setName(rs.getString(2));
						gdo.setKind(rs.getString(3));
						gdo.setPrice(rs.getString(4));
						gdo.setCnt(rs.getString(5));
						gdo.setStar(rs.getInt(6));
						gdo.setDate(rs.getString(7));
						gList.add(gdo);
					}
					System.out.println("SortHos() ó�� ����");
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
				disconnect();
			}
			
			else if (st.equals("2")) {
				String sql = "select * from goods order by kind desc";
				try {
					pstmt = conn.prepareStatement(sql);
					rs = pstmt.executeQuery();
					while (rs.next()) {
						goodsBean gdo = new goodsBean();
						gdo.setNum(rs.getInt(1));
						gdo.setName(rs.getString(2));
						gdo.setKind(rs.getString(3));
						gdo.setPrice(rs.getString(4));
						gdo.setCnt(rs.getString(5));
						gdo.setStar(rs.getInt(6));
						gdo.setDate(rs.getString(7));
						gList.add(gdo);
					}
					System.out.println("SortHos() ó�� ����");
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
				disconnect();
			}
			
			else if (st.equals("3")) {
				String sql = "select * from goods order by star desc";
				try {
					pstmt = conn.prepareStatement(sql);
					rs = pstmt.executeQuery();
					while (rs.next()) {
						goodsBean gdo = new goodsBean();
						gdo.setNum(rs.getInt(1));
						gdo.setName(rs.getString(2));
						gdo.setKind(rs.getString(3));
						gdo.setPrice(rs.getString(4));
						gdo.setCnt(rs.getString(5));
						gdo.setStar(rs.getInt(6));
						gdo.setDate(rs.getString(7));
						gList.add(gdo);
					}
					System.out.println("SortHos() ó�� ����");
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
				disconnect();
			}
			
			else if (st.equals("4")) {
				String sql = "select * from goods order by date desc";
				try {
					pstmt = conn.prepareStatement(sql);
					rs = pstmt.executeQuery();
					while (rs.next()) {
						goodsBean gdo = new goodsBean();
						gdo.setNum(rs.getInt(1));
						gdo.setName(rs.getString(2));
						gdo.setKind(rs.getString(3));
						gdo.setPrice(rs.getString(4));
						gdo.setCnt(rs.getString(5));
						gdo.setStar(rs.getInt(6));
						gdo.setDate(rs.getString(7));
						gList.add(gdo);
					}
					System.out.println("SortHos() ó�� ����");
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
				disconnect();
			}
		}
		return gList;
	}
	
	
}
