package userPet;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class hospitalDAO {
	Connection conn;
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	public void connect_cp() {
		try {
			Context initctx = new InitialContext();
			Context envctx = (Context) initctx.lookup("java://comp/env");
			DataSource ds = (DataSource) envctx.lookup("jdbc/pool");
			conn = ds.getConnection();
			System.out.println("Ŀ�ؼ�Ǯ�� DB ���� ����");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void disconnect() {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (pstmt != null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		System.out.println("disconnection ����");
	}

	public void insertHos(hospitalBean hdo) {
		connect_cp();

		String sql = "insert into hospital values (null,?,?,?,?,?,?)";

		try {
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, hdo.getName());
			pstmt.setString(2, hdo.getTell());
			pstmt.setString(3, hdo.getReason());
			pstmt.setString(4, hdo.getDiagnosticName());
			pstmt.setString(5, hdo.getPrescription());
			pstmt.setString(6, hdo.getDate());

			pstmt.executeUpdate();
			System.out.println("insertHos() ó��");
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	public ArrayList<hospitalBean> getAllHos() {
		connect_cp();
		ArrayList<hospitalBean> hList = new ArrayList<hospitalBean>();
		String sql = "select * from hospital";
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				hospitalBean hdo = new hospitalBean();
				hdo.setNum(rs.getInt(1));
				hdo.setName(rs.getString(2));
				hdo.setTell(rs.getString(3));
				hdo.setReason(rs.getString(4));
				hdo.setDiagnosticName(rs.getString(5));
				hdo.setPrescription(rs.getString(6));
				hdo.setDate(rs.getString(7));
				hList.add(hdo);
			}
			System.out.println("getAllHos() ó��");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		disconnect();
		return hList;
	}
	
	public hospitalBean getHosOne(int num) {
		connect_cp();
		hospitalBean hdo = new hospitalBean();
		String sql = "select * from hospital where num=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				hdo.setNum(rs.getInt(1));
				hdo.setName(rs.getString(2));
				hdo.setTell(rs.getString(3));
				hdo.setReason(rs.getString(4));
				hdo.setDiagnosticName(rs.getString(5));
				hdo.setPrescription(rs.getString(6));
				hdo.setDate(rs.getString(7));
			}
			System.out.println("getHos() ó��");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		disconnect();
		return hdo;
	}

	
	public void hospitalM(hospitalBean hdo) {
		connect_cp();
	  
	    String sql = "update hospital set name=?, tell=?, reason=?, diagnosticName=?, prescription=?, date=? where num=?";
	    try {
	    	pstmt=conn.prepareStatement(sql);
	    	
	    	pstmt.setString(1, hdo.getName());
	    	pstmt.setString(2, hdo.getTell());
	    	pstmt.setString(3, hdo.getReason());
	    	pstmt.setString(4, hdo.getDiagnosticName());
	    	pstmt.setString(5, hdo.getPrescription());
	    	pstmt.setString(6, hdo.getDate());
	    	pstmt.setInt(7, hdo.getNum());
	    	pstmt.executeUpdate();
	    	
	    	System.out.println("hospitalM() �Ϸ�");
	    } catch (SQLException e) {
	    	e.printStackTrace();
	    }
	    disconnect();
	}
	 

	public void deleteHos(int num) {
		connect_cp();

		String sql = "delete from hospital where num=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.executeUpdate();

			System.out.println("deleteHos() ó��");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		disconnect();
	}
	
	
	//search
	public ArrayList<hospitalBean> searchHos(String k, String v) {
		connect_cp();
		ArrayList<hospitalBean> hList = new ArrayList<hospitalBean>();
		
		if(k.equals("name")) {
			String sql = "select * from hospital where name like ?";
			try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1,"%" + v + "%");
				rs = pstmt.executeQuery();
				
				while(rs.next()) {
					hospitalBean hdo = new hospitalBean();
					hdo.setNum(rs.getInt(1));
					hdo.setName(rs.getString(2));
					hdo.setTell(rs.getString(3));
					hdo.setReason(rs.getString(4));
					hdo.setDiagnosticName(rs.getString(5));
					hdo.setPrescription(rs.getString(6));
					hdo.setDate(rs.getString(7));
					hList.add(hdo);
					
					System.out.println("ggg");
				}
			} catch(SQLException e) {
				e.printStackTrace();
			}
		}
		else if(k.equals("dname")) {
			String sql = "select * from hospital where diagnosticName like ?";
			try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, "%" + v + "%");
				rs = pstmt.executeQuery();
				
				while(rs.next()) {
					hospitalBean hdo = new hospitalBean();
					hdo.setNum(rs.getInt(1));
					hdo.setName(rs.getString(2));
					hdo.setTell(rs.getString(3));
					hdo.setReason(rs.getString(4));
					hdo.setDiagnosticName(rs.getString(5));
					hdo.setPrescription(rs.getString(6));
					hdo.setDate(rs.getString(7));
					hList.add(hdo);
				}
					System.out.println("sss");
			} catch(SQLException e) {
				e.printStackTrace();
			}
		}
		disconnect();
		return hList;
	}
	
	
	//sort
	public ArrayList<hospitalBean> sortHos(String st, String sort){
		connect_cp();
		ArrayList<hospitalBean> hList = new ArrayList<hospitalBean>();
		if (sort.equals("asc")) {
			if (st.equals("1")) {
				String sql = "select * from hospital order by name asc";
				try {
					pstmt = conn.prepareStatement(sql);
					rs = pstmt.executeQuery();
					while (rs.next()) {
						hospitalBean hdo = new hospitalBean();
						hdo.setNum(rs.getInt(1));
						hdo.setName(rs.getString(2));
						hdo.setTell(rs.getString(3));
						hdo.setReason(rs.getString(4));
						hdo.setDiagnosticName(rs.getString(5));
						hdo.setPrescription(rs.getString(6));
						hdo.setDate(rs.getString(7));
						hList.add(hdo);
					}
					System.out.println("sortHos() ó�� ����");
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
				disconnect();
			}
			
			else if (st.equals("2")) {
				String sql = "select * from hospital order by diagnosticName asc";
				try {
					pstmt = conn.prepareStatement(sql);
					rs = pstmt.executeQuery();
					while (rs.next()) {
						hospitalBean hdo = new hospitalBean();
						hdo.setNum(rs.getInt(1));
						hdo.setName(rs.getString(2));
						hdo.setTell(rs.getString(3));
						hdo.setReason(rs.getString(4));
						hdo.setDiagnosticName(rs.getString(5));
						hdo.setPrescription(rs.getString(6));
						hdo.setDate(rs.getString(7));
						hList.add(hdo);
					}
					System.out.println("sortHos() ó�� ����");
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
				disconnect();
			}
			
			else if (st.equals("3")) {
				String sql = "select * from hospital order by prescription asc";
				try {
					pstmt = conn.prepareStatement(sql);
					rs = pstmt.executeQuery();
					while (rs.next()) {
						hospitalBean hdo = new hospitalBean();
						hdo.setNum(rs.getInt(1));
						hdo.setName(rs.getString(2));
						hdo.setTell(rs.getString(3));
						hdo.setReason(rs.getString(4));
						hdo.setDiagnosticName(rs.getString(5));
						hdo.setPrescription(rs.getString(6));
						hdo.setDate(rs.getString(7));
						hList.add(hdo);
					}
					System.out.println("sortHos() ó�� ����");
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
				disconnect();
			}
			
			else if (st.equals("4")) {
				String sql = "select * from hospital order by date asc";
				try {
					pstmt = conn.prepareStatement(sql);
					rs = pstmt.executeQuery();
					while (rs.next()) {
						hospitalBean hdo = new hospitalBean();
						hdo.setNum(rs.getInt(1));
						hdo.setName(rs.getString(2));
						hdo.setTell(rs.getString(3));
						hdo.setReason(rs.getString(4));
						hdo.setDiagnosticName(rs.getString(5));
						hdo.setPrescription(rs.getString(6));
						hdo.setDate(rs.getString(7));
						hList.add(hdo);
					}
					System.out.println("sortHos() ó�� ����");
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
				disconnect();
			}
		} else if (sort.equals("desc")) {
			if (st.equals("1")) {
				String sql = "select * from hospital order by name desc";
				try {
					pstmt = conn.prepareStatement(sql);
					rs = pstmt.executeQuery();
					while (rs.next()) {
						hospitalBean hdo = new hospitalBean();
						hdo.setNum(rs.getInt(1));
						hdo.setName(rs.getString(2));
						hdo.setTell(rs.getString(3));
						hdo.setReason(rs.getString(4));
						hdo.setDiagnosticName(rs.getString(5));
						hdo.setPrescription(rs.getString(6));
						hdo.setDate(rs.getString(7));
						hList.add(hdo);
					}
					System.out.println("sortHos() ó�� ����");
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
				disconnect();
			}
			
			else if (st.equals("2")) {
				String sql = "select * from hospital order by diagnosticName desc";
				try {
					pstmt = conn.prepareStatement(sql);
					rs = pstmt.executeQuery();
					while (rs.next()) {
						hospitalBean hdo = new hospitalBean();
						hdo.setNum(rs.getInt(1));
						hdo.setName(rs.getString(2));
						hdo.setTell(rs.getString(3));
						hdo.setReason(rs.getString(4));
						hdo.setDiagnosticName(rs.getString(5));
						hdo.setPrescription(rs.getString(6));
						hdo.setDate(rs.getString(7));
						hList.add(hdo);
					}
					System.out.println("sortHos() ó�� ����");
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
				disconnect();
			}
			
			else if (st.equals("3")) {
				String sql = "select * from hospital order by prescription desc";
				try {
					pstmt = conn.prepareStatement(sql);
					rs = pstmt.executeQuery();
					while (rs.next()) {
						hospitalBean hdo = new hospitalBean();
						hdo.setNum(rs.getInt(1));
						hdo.setName(rs.getString(2));
						hdo.setTell(rs.getString(3));
						hdo.setReason(rs.getString(4));
						hdo.setDiagnosticName(rs.getString(5));
						hdo.setPrescription(rs.getString(6));
						hdo.setDate(rs.getString(7));
						hList.add(hdo);
					}
					System.out.println("sortHos() ó�� ����");
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
				disconnect();
			}
			
			else if (st.equals("4")) {
				String sql = "select * from hospital order by date desc";
				try {
					pstmt = conn.prepareStatement(sql);
					rs = pstmt.executeQuery();
					while (rs.next()) {
						hospitalBean hdo = new hospitalBean();
						hdo.setNum(rs.getInt(1));
						hdo.setName(rs.getString(2));
						hdo.setTell(rs.getString(3));
						hdo.setReason(rs.getString(4));
						hdo.setDiagnosticName(rs.getString(5));
						hdo.setPrescription(rs.getString(6));
						hdo.setDate(rs.getString(7));
						hList.add(hdo);
					}
					System.out.println("sortHos() ó�� ����");
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
				disconnect();
			}
		}
		return hList;
	}
	
}
